package com.CalculadoraIMC.imc.main;

import com.CalculadoraIMC.imc.view.VentanaIMC;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

/**
 *
 * @author Victor Perez Martinez
 */
public class Main {

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
        }

        SwingUtilities.invokeLater(() -> {
            VentanaIMC ventana = new VentanaIMC();
            ventana.setVisible(true);
        });
    }
}