/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.CalculadoraIMC.imc.controller;

import com.CalculadoraIMC.imc.model.CalculadoraIMC;
import com.CalculadoraIMC.imc.view.VentanaIMC;
import java.awt.Color;

/**
 *
 * @author Victor Perez Martinez
 */
public class IMCController {

    private final VentanaIMC vista;
    private final CalculadoraIMC calculadora;

    public IMCController(VentanaIMC vista) {
        this.vista = vista;
        this.calculadora = new CalculadoraIMC();
    }

    public void procesarCalculo() {
        String textoPeso = vista.getTxtPeso().getText().trim().replace(',', '.');
        String textoAltura = vista.getTxtAltura().getText().trim().replace(',', '.');

        double peso;
        double altura;

        try {
            peso = Double.parseDouble(textoPeso);
            altura = Double.parseDouble(textoAltura);

            if (peso <= 0 || altura <= 0) {
                mostrarError("Error: Los valores deben ser mayores a 0");
                return;
            }
        } catch (NumberFormatException e) {
            mostrarError("Error: Introduce solo números válidos");
            return;
        }

        double imc = calculadora.calcular(peso, altura);
        String clasificacion = calculadora.clasificar(imc);

        vista.getLblResultado().setText(String.format("Tu IMC es: %.2f", imc));
        vista.getLblResultado().setForeground(Color.BLACK);

        vista.getLblClasificacion().setText("Clasificación: " + clasificacion);
        
        actualizarColorClasificacion(clasificacion);
    }

    private void mostrarError(String mensaje) {
        vista.getLblResultado().setText(mensaje);
        vista.getLblResultado().setForeground(Color.RED);
        vista.getLblClasificacion().setText("");
    }

    private void actualizarColorClasificacion(String clasificacion) {
        switch (clasificacion) {
            case "Peso Normal":
                vista.getLblClasificacion().setForeground(new Color(34, 139, 34)); 
                break;
            case "Bajo Peso":
            case "Sobrepeso":
                vista.getLblClasificacion().setForeground(new Color(230, 126, 34)); 
                break;
            case "Obesidad":
                vista.getLblClasificacion().setForeground(Color.RED); 
                break;
            default:
                vista.getLblClasificacion().setForeground(Color.BLACK);
                break;
        }
    }
}